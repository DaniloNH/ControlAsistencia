-- Crear la base de datos si no existe
CREATE DATABASE GestorControl2;

-- Usar la base de datos
USE GestorControl2;
